package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class LoginPage extends ProjectSpecificMethod{

	public LoginPage(ChromeDriver driver, ExtentTest node) {
		this.driver=driver;
		this.node=node;
	}
	
	public LoginPage enterUsername() throws IOException {
		try {
			driver.findElement(By.id("username")).sendKeys("jennifer@testleaf.com");
			reportStep("Entered Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not entered"+e, "fail");
		}
		return this;
	}
	
	public LoginPage enterPassword() throws IOException {
		try {
			driver.findElement(By.id("password")).sendKeys("jason@2023");
			reportStep("Entered Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not entered"+e, "fail");
		}
		return this;
	}
	
	public SalesforceHome clickLogin() throws IOException {
		try {
			driver.findElement(By.id("Login")).click();
			reportStep("clicked Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not clicked"+e, "fail");
		}
		return new SalesforceHome(driver, node);
	}
}
