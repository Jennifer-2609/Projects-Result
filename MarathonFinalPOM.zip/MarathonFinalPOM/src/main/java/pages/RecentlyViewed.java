package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class RecentlyViewed  extends ProjectSpecificMethod {

	public RecentlyViewed(ChromeDriver driver, ExtentTest node) {
		this.driver=driver;
		this.node=node;
	}
	
	public RecentlyViewed clickNewIndividual() throws IOException {
		try {
			driver.findElement(By.xpath("//div[@title='New']")).click();
			reportStep("clicked Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not clicked"+e, "fail");
		}
		return this;
	}
	
	public RecentlyViewed enterLastname(String Lastname) throws IOException {
		try {
			driver.findElement(By.xpath("//input[contains(@class,'lastName compound')]")).sendKeys(Lastname);
			reportStep("entered Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not entered"+e, "fail");
		}
		return this;
		
	}
	
	public Verification clickSave() throws IOException {
		try {
			driver.findElement(By.xpath("(//span[text()='Save'])[2]")).click();
			reportStep("clicked Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not clicked"+e, "fail");
		}
		return new Verification(driver, node);
	}
	
	public RecentlyViewed enterSearchname() throws IOException {
		try {
			WebElement name =driver.findElement(By.xpath("//input[@name='Individual-search-input']"));
			name.sendKeys("Jason");
			name.sendKeys(Keys.ENTER);
			reportStep("entered Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not entered"+e, "fail");
		}
		return this;
	}
	
	public RecentlyViewed clickPlaceholder() throws InterruptedException, IOException {
		try {
			Thread.sleep(3000);
			WebElement ele = driver.findElement(By.xpath("//div[@class='forceVirtualActionMarker forceVirtualAction']/a[@role='button']"));
			driver.executeScript("arguments[0].click();", ele);
			reportStep("clicked Sucessfully","pass");
			
		} catch (InterruptedException e) {
			reportStep("Not clicked"+e, "fail");
		}
		return this;
	}
	
	public RecentlyViewed clickEdit() throws InterruptedException, IOException {
		try {
			Thread.sleep(3000);
			WebElement edit = driver.findElement(By.xpath("//a[@title='Edit']/div"));
			driver.executeScript("arguments[0].click();", edit);
			reportStep("clicked Sucessfully","pass");
		} catch (InterruptedException e) {
			reportStep("Not clicked"+e, "fail");
		}
		return this;
	}
	
	public RecentlyViewed enterSalutation() throws IOException {
		try {
			driver.findElement(By.xpath("//a[@class='select']")).click();
			driver.findElement(By.xpath("//a[text()='Mr.']")).click();
			reportStep("entered Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not entered"+e, "fail");
		}
		return this;
	}
	
	
	public RecentlyViewed enterFirstname(String Firstname) throws IOException {
		try {
			driver.findElement(By.xpath("//input[contains(@class,'firstName')]")).sendKeys(Firstname);
			reportStep("entered Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not entered"+e, "fail");
		}
		return this;
	}
	
	public RecentlyViewed clickplaceholderdelete() throws InterruptedException, IOException {
		try {
			Thread.sleep(3000);
			WebElement delete = driver.findElement(By.xpath("//a[@role='menuitem']/div[@title='Delete']"));
			driver.executeScript("arguments[0].click();", delete);
			reportStep("clicked Sucessfully","pass");
		} catch (InterruptedException e) {
			reportStep("Not clicked","fail");
		}
		return this;
	}
	
	
	public Verification clickDelete() throws InterruptedException, IOException {
		try {
			Thread.sleep(3000);
			driver.findElement(By.xpath("//span[text()='Delete']")).click();
			reportStep("clicked Sucessfully","pass");
		} catch (InterruptedException e) {
			reportStep("Not clicked","fail");
		}
		return new Verification(driver, node);
	}
	
	public RecentlyViewed enterSearchname1() throws IOException {
		try {
			driver.findElement(By.xpath("//input[@class='slds-input']")).clear();
			driver.findElement(By.xpath("//input[@class='slds-input']")).sendKeys("Jason",Keys.ENTER);
			reportStep("entered Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not entered"+e, "fail");
		}
		return this;
	}
	
	public RecentlyViewed verifyNotdisplay() throws InterruptedException, IOException {
		try {
			Thread.sleep(3000);
			 String text = driver.findElement(By.xpath("//span[text()='No items to display.']")).getText();
			//Verify Whether Individual is Deleted using Individual last name"
			 System.out.println(text);
			 reportStep("verified Sucessfully","pass");
		} catch (InterruptedException e) {
			reportStep("Not verified ","fail");
		}
		 return this;
	}
}
