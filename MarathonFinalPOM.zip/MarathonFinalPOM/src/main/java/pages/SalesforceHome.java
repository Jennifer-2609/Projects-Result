package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class SalesforceHome extends ProjectSpecificMethod {

	public SalesforceHome(ChromeDriver driver, ExtentTest node) {
		this.driver=driver;
		this.node=node;
	}
	
	public SalesforceHome clickAppLauncher() throws IOException {
		try {
			driver.findElement(By.xpath("//div[@class='slds-icon-waffle']")).click();
			reportStep("clicked Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not clicked"+e, "fail");
		}
		return this;
	}
	
	public SalesforceHome clickViewAll() throws IOException {
		try {
			driver.findElement(By.xpath("//button[text()='View All']")).click();
			reportStep("clicked Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not clicked"+e, "fail");
		}
		return this;
	}
	
	public SalesforceHome runScroll() throws IOException {
		try {
			WebElement scroll = driver.findElement(By.xpath("//p[text()='Party Consent']"));
			driver.executeScript("arguments[0].scrollIntoView();", scroll);
			reportStep("scrolled Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not scrolled"+e, "fail");
		}
		return this;
	}
	
	public RecentlyViewed clickIndividual() throws IOException {
		try {
			WebElement individual = driver.findElement(By.xpath("//p[text()='Individuals']"));
			driver.executeScript("arguments[0].click();", individual);
			reportStep("clicked Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not clicked"+e, "fail");
		}
		return new RecentlyViewed(driver, node);
	}
}
