package pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import com.aventstack.extentreports.ExtentTest;

import base.ProjectSpecificMethod;

public class Verification extends ProjectSpecificMethod {

	public Verification(ChromeDriver driver, ExtentTest node) {
		this.driver=driver;
		this.node=node;
	}
	
	public Verification verificationMessage() throws IOException {
		try {
			String message = driver.findElement(By.xpath("//span[contains(@class,'toastMessage')]")).getText();
			System.out.println(message);
			reportStep("verified Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not verified ","fail");
		}
		return this;
	}
	
	public Verification verificationMessage1() throws IOException {
		try {
			String message = driver.findElement(By.xpath("//span[contains(@class,'toastMessage')]")).getText();
			System.out.println(message);
			reportStep("verified Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not verified ","fail");
		}
		return this;
}
	public Verification verificationMessage2() throws IOException {
		try {
			String message = driver.findElement(By.xpath("//span[contains(@class,'toastMessage')]")).getText();
			System.out.println(message);
			reportStep("verified Sucessfully","pass");
		} catch (Exception e) {
			reportStep("Not verified ","fail");
		}
		return this;
}
}
