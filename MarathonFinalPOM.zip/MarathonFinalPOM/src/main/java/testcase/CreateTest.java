package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class CreateTest extends ProjectSpecificMethod  {

	@BeforeTest
	public void setup() {
		sheet="Create";
		testName="CreateIndividual";
		testDescription="Give valid details";
		testCategory="POM";
		testAuthor="Jennifer";
	}
	
	@Test(dataProvider="fetchdata")
	public void runCreateTest(String Lastname) throws IOException {
		
		LoginPage lp=new LoginPage(driver, node);
		lp.enterUsername().enterPassword().clickLogin().clickAppLauncher()
		.clickViewAll().runScroll().clickIndividual().clickNewIndividual()
		.enterLastname(Lastname).clickSave().verificationMessage();
		
	}
}
