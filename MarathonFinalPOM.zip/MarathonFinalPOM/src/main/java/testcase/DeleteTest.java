package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;
import pages.RecentlyViewed;

public class DeleteTest extends ProjectSpecificMethod{

	@BeforeTest
	public void setup() {
		
		testName="DeleteIndividual";
		testDescription="delete an individual";
		testCategory="POM";
		testAuthor="Jennifer";
	}
	
	@Test
public void runEditTest() throws InterruptedException, IOException {
		
		LoginPage lp=new LoginPage(driver, node);
		lp.enterUsername().enterPassword().clickLogin().clickAppLauncher()
		.clickViewAll().runScroll().clickIndividual().enterSearchname().clickPlaceholder().clickplaceholderdelete()
		.clickDelete().verificationMessage2();
		RecentlyViewed rv=new RecentlyViewed(driver, node);
		rv.enterSearchname1().verifyNotdisplay();
		
	}
}
