package testcase;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethod;
import pages.LoginPage;

public class EditTest extends ProjectSpecificMethod{

	@BeforeTest
	public void setup() {
		sheet="Edit";
		testName="EditIndividual";
		testDescription="Give valid details";
		testCategory="POM";
		testAuthor="Jennifer";
	}
	
	@Test(dataProvider="fetchdata")
public void runEditTest(String Firstname) throws InterruptedException, IOException {
		
		LoginPage lp=new LoginPage(driver, node);
		lp.enterUsername().enterPassword().clickLogin().clickAppLauncher()
		.clickViewAll().runScroll().clickIndividual().enterSearchname().clickPlaceholder().clickEdit()
		.enterSalutation().enterFirstname(Firstname).clickSave().verificationMessage1();
		
	}
}
